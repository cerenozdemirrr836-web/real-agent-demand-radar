const { loadSnapshots, listSnapshotMeta, getToken } = require('../lib/storage');
const { computeIntelligence } = require('../lib/intelligence');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Cache-Control', 's-maxage=30, stale-while-revalidate=60');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  try {
    if (!getToken()) {
      return res.status(200).json({
        ok: false,
        status: 'WATCH',
        demand: 'UNAVAILABLE',
        acceleration: 'UNAVAILABLE',
        priority: 'LOW',
        buyerGrowth: 'UNAVAILABLE',
        spendGrowth: 'UNAVAILABLE',
        repeatUsage: 'UNAVAILABLE',
        transactionGrowth: 'UNAVAILABLE',
        workflowDepth: 'UNAVAILABLE',
        lastSuccessfulFetch: null,
        snapshotCount: 0,
        signals: ['BLOB_READ_WRITE_TOKEN missing. Add it in Vercel Environment Variables.'],
        note: 'Storage not configured',
        currentMetrics: null
      });
    }

    const { snapshots, error } = await loadSnapshots(25);

    if (error && snapshots.length === 0) {
      return res.status(200).json({
        ok: false,
        status: 'WATCH',
        demand: 'UNAVAILABLE',
        acceleration: 'UNAVAILABLE',
        priority: 'LOW',
        buyerGrowth: 'UNAVAILABLE',
        spendGrowth: 'UNAVAILABLE',
        repeatUsage: 'UNAVAILABLE',
        transactionGrowth: 'UNAVAILABLE',
        workflowDepth: 'UNAVAILABLE',
        lastSuccessfulFetch: null,
        snapshotCount: 0,
        signals: [error || 'No data yet. Press REFRESH DATA.'],
        note: 'Waiting for first collection',
        currentMetrics: null
      });
    }

    const intel = computeIntelligence(snapshots);
    const meta = await listSnapshotMeta(5);

    return res.status(200).json({
      ok: true,
      status: intel.status,
      demand: intel.demand,
      acceleration: intel.acceleration,
      priority: intel.priority,
      buyerGrowth: intel.buyerGrowth,
      spendGrowth: intel.spendGrowth,
      repeatUsage: intel.repeatUsage,
      transactionGrowth: intel.transactionGrowth,
      workflowDepth: intel.workflowDepth,
      lastSuccessfulFetch: intel.lastSuccessfulFetch,
      snapshotCount: intel.snapshotCount,
      signals: intel.signals,
      note: intel.note,
      currentMetrics: intel.currentMetrics,
      recentMeta: meta.snapshots || []
    });
  } catch (e) {
    return res.status(500).json({
      ok: false,
      status: 'WATCH',
      demand: 'UNAVAILABLE',
      acceleration: 'UNAVAILABLE',
      priority: 'LOW',
      error: e.message,
      signals: ['Radar error: ' + (e.message || 'unknown')],
      snapshotCount: 0
    });
  }
};
