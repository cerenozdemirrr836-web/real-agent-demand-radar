const { listSnapshotMeta, loadSnapshots, getToken } = require('../lib/storage');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Cache-Control', 's-maxage=60, stale-while-revalidate=120');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  try {
    if (!getToken()) {
      return res.status(200).json({
        ok: false,
        count: 0,
        snapshots: [],
        message: 'BLOB_READ_WRITE_TOKEN not set'
      });
    }

    const limit = Math.min(parseInt(req.query.limit || '30', 10) || 30, 90);
    const full = req.query.full === '1';

    if (full) {
      const { snapshots, error } = await loadSnapshots(limit);
      return res.status(200).json({
        ok: !error,
        count: snapshots.length,
        error: error || null,
        snapshots: snapshots.map(s => ({
          id: s.id,
          fetchedAt: s.fetchedAt,
          success: s.success,
          metrics: s.metrics,
          depth: s.depth
        }))
      });
    }

    const { snapshots, error, count } = await listSnapshotMeta(limit);
    return res.status(200).json({
      ok: !error,
      count: count || snapshots.length,
      error: error || null,
      snapshots
    });
  } catch (e) {
    return res.status(500).json({
      ok: false,
      count: 0,
      snapshots: [],
      error: e.message
    });
  }
};
