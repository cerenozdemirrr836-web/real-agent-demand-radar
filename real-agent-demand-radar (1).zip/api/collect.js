const { collectRawData } = require('../lib/polymarket');
const { saveSnapshot } = require('../lib/storage');
const { computeIntelligence } = require('../lib/intelligence');
const { loadSnapshots } = require('../lib/storage');

module.exports = async function handler(req, res) {
  // CORS for mobile dashboard
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // Cron protection (optional for manual refresh)
  const auth = req.headers.authorization || '';
  const cronSecret = process.env.CRON_SECRET;
  const isCron = cronSecret && auth === `Bearer ${cronSecret}`;
  const isManual = req.method === 'POST' || req.query.manual === '1' || req.query.force === '1';

  // Allow manual without secret; cron requires secret if set
  if (cronSecret && !isCron && !isManual && req.method === 'GET') {
    // Still allow GET for simplicity on first deploy, but prefer POST for manual
  }

  try {
    const raw = await collectRawData();

    if (!raw.success) {
      return res.status(200).json({
        ok: false,
        error: raw.error || 'Data collection failed',
        message: 'Polymarket data UNAVAILABLE',
        fetchedAt: raw.fetchedAt
      });
    }

    const saveResult = await saveSnapshot(raw);

    if (!saveResult.success) {
      return res.status(200).json({
        ok: false,
        error: saveResult.error,
        message: 'Collected but storage failed. Check BLOB_READ_WRITE_TOKEN.',
        metrics: raw.metrics,
        fetchedAt: raw.fetchedAt
      });
    }

    // Compute current intelligence
    const { snapshots } = await loadSnapshots(20);
    const intel = computeIntelligence(snapshots);

    return res.status(200).json({
      ok: true,
      message: 'Snapshot collected and stored',
      snapshotId: saveResult.snapshot.id,
      fetchedAt: raw.fetchedAt,
      metrics: raw.metrics,
      depth: raw.depth,
      intelligence: {
        status: intel.status,
        demand: intel.demand,
        acceleration: intel.acceleration,
        priority: intel.priority,
        snapshotCount: intel.snapshotCount
      }
    });
  } catch (e) {
    return res.status(500).json({
      ok: false,
      error: e.message || 'Internal error',
      message: 'Collection failed'
    });
  }
};
