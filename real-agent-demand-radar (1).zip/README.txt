REAL AGENT DEMAND RADAR - Vercel ZIP Kurulum (Telefon)

1. Vercel.com → New Project → Upload klasör/ZIP (bu dosyanın içindeki tüm içerik).
2. Environment Variables ekle:
   - BLOB_READ_WRITE_TOKEN (Vercel Storage → Blob → Create Store → Token al)
   - CRON_SECRET (rastgele 20+ karakter şifre)
3. Deploy et. Production domain açılınca site hazır.
4. Dashboard'da REFRESH DATA bas → ilk snapshot alınır.
5. Cron her 2 saatte otomatik toplar. 7 snapshot sonra velocity aktif olur.

Not: Blob store'u projeye bağla (Storage → Connect). Token'ı Production + Preview'a ekle.
